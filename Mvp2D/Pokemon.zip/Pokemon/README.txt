STANDARD SETUP

1. Go to the following location:

C:\Users\<user>\AppData\Roaming\Wonderdraft\assets

2. Copy the folder "Pokemon" into this location.

3. Start Wonderdraft.